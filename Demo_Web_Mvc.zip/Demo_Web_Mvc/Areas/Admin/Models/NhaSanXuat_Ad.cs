﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Demo_Web_Mvc.Areas.Admin.Models
{
    public class NhaSanXuat_Ad
    {
        public int MaNSX{ get; set; }
        public string TenNSX { get; set; }
    }
}