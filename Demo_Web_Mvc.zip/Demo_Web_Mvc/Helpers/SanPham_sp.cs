﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Demo_Web_Mvc.Helpers
{
    public class SanPham_sp
    {
        public int MASP { get; set; }
        public String TenSP { get; set; }
    }
}